a.
b.
neg(F) :- F.
or(F,G) :- F, G.
fmla(F) :- F.
imp(F,G) :- F, G.
and(F,G) :- F, G.
iff(F,G) :- F, G.
sub(F,G) :- F, G, G(F).