README

I typed the homework using OpenOffice word processor. So I added a pdf version of the file just in case the word document was not readable.